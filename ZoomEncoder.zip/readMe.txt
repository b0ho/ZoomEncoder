ZoomEncoder 1.0


How to use


This is quality improvement program for video.

You can 'Upload' original video and 'convert' video for better quality.

You can also use the 'test convert' to determine the expected time or PSNR reading.

You can set the 'options' and check the 'history'.



Caution


This can be time-consuming, depending on your computer's performance.

It needs enough free space for the convert operation.

This program is optimized for Hangul(Korean).



license


Waifu2x Copyright (C) 2015 nagadomi
Waifu2x-Caffe Coppyright (C) 2015 lltcggie
FFMpeg
FFProbe
Caffe

This program follows the licenses LGPL, MIT and BSD 2-Clause.



Copyright (C) 2017 Team DBLAB

